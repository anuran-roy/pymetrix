import analyx.settings as s

for plg in s.PLUGINS:
    globals()[f"{plg}.models"] = __import__(f"{plg}.models")