DEBUG = True
VERBOSE = True

plugins = [
    "test_plugin",
]