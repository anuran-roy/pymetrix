from setuptools import setup


setup(
    name="test_plugin",
    version="0.0.1",
    description="A simple Analyx test plugin.",
    # url="http://github.com/anuran-roy/analyx-python",
    author="Anuran Roy",
    author_email="anuranroy02@gmail.com",
    license="MIT",
    packages=["test_plugin"],
    zip_safe=False,
)
